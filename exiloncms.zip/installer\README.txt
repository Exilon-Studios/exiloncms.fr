========================================
  INSTALLATION RAPIDE EXILONCMS
========================================

Cet installateur télécharge automatiquement
ExilonCMS depuis GitHub - pas besoin de
télécharger le gros zip !

:: INSTALLATION ::

1. Uploadez ces 2 fichiers sur votre serveur:
   - install.php
   - public/ (dossier)

2. Visitez votre site web:
   https://votre-site.com/install.php

3. Cliquez sur "Installer ExilonCMS"

4. Suivez l'installateur web

:: PRÉREQUIS SERVEUR ::

- PHP 8.2 ou supérieur
- Extensions: BCMath, CType, JSON, MBString,
  OpenSSL, PDO, Tokenizer, XML, Curl,
  FileInfo, Zip

:: QUESTIONS ? ::

Documentation: https://github.com/Exilon-Studios/ExilonCMS
Support: https://github.com/Exilon-Studios/ExilonCMS/issues

========================================
