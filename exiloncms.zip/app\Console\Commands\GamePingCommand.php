<?php

namespace ExilonCMS\Console\Commands;

use ExilonCMS\Models\Server;
use ExilonCMS\Models\Setting;
use Illuminate\Console\Command;

class GamePingCommand extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'game:ping';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Ping the game servers to update their stats.';

    /**
     * Execute the console command.
     */
    public function handle()
    {
        Setting::updateSettings('schedule.last', now()->toISOString());

        $servers = Server::pingable()->get();

        foreach ($servers as $server) {
            $data = $server->bridge()->getServerData();

            $server->updateData($data, now()->minute % 15 === 0);
        }

        $this->info($servers->count().' server(s) were successfully pinged.');
    }
}
