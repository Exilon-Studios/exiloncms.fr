<?php

return [
    'title' => 'Shop',
    'order_number' => 'Order #:id',
    'recent_orders' => 'Recent Orders',
    'no_orders' => 'No recent orders',
];
