<?php

return [
    'pending' => 'En attente',
    'completed' => 'Livré',
    'cancelled' => 'Annulé',
    'refunded' => 'Remboursé',
];

