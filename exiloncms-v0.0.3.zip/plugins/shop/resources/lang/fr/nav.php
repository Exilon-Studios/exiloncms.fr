<?php

return [
    'admin' => 'Gérer la boutique',
    'shop' => 'Voir la boutique',
    'shop_description' => 'Acheter des articles et des prestiges',
    'orders' => 'Mes commandes',
    'orders_description' => 'Voir l\'historique de mes commandes',
    'invoices' => 'Mes factures',
    'invoices_description' => 'Télécharger mes factures',
];
