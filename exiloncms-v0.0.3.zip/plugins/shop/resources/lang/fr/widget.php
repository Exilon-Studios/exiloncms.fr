<?php

return [
    'title' => 'Boutique',
    'order_number' => 'Commande #:id',
    'recent_orders' => 'Commandes récentes',
    'no_orders' => 'Aucune commande récente',
];

