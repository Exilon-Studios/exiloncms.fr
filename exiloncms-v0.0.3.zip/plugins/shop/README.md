# Shop Plugin

Système de boutique complet pour ExilonCMS avec paiements multiples et facturation.

## Installation

Ce plugin est automatiquement installé via le marketplace ExilonCMS.

## Fonctionnalités

- Gestion complète de boutique
- Paiements multiples (PayPal, Stripe, etc.)
- Facturation
- Gestion des commandes
- Système de panier

## Version

- Version actuelle: 1.0.0
- Compatible avec ExilonCMS 0.2+

## Auteur

ExilonStudios
