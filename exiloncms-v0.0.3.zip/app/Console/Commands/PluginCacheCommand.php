<?php

namespace ExilonCMS\Console\Commands;

use ExilonCMS\Extensions\Plugin\PluginManager;
use Illuminate\Console\Command;

class PluginCacheCommand extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'plugin:cache';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Cache the plugins service providers';

    /**
     * Execute the console command.
     */
    public function handle(PluginManager $plugins)
    {
        $plugins->cachePlugins();

        $this->info('Cached plugins files generated successfully.');
    }
}
