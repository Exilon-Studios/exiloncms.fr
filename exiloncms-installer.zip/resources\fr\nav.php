<?php

// Alias vers les traductions de navigation du plugin shop
// Ce fichier permet à l'éditeur de traduction en ligne de trouver les clés

return array (
      'admin' => 'Gérer la boutique',
      'shop' => 'Voir la boutique',
      'orders' => 'Mes commandes',
      'invoices' => 'Mes factures',
    );
