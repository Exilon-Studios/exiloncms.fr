<?php

return array (
      'id' => 'ID',
    );
