import{c as o}from"./app-CPNocFrY.js";const c=[["path",{d:"M5 12h14",key:"1ays0h"}]],e=o("minus",c);export{e as M};
