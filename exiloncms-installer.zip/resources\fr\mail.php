<?php

return array (
      'delete' => array (
        'subject' => 'Suppression de votre compte',
        'line1' => 'Vous recevez cet email car votre compte est sur le point d\'être supprimé.',
        'action' => 'Annuler la suppression',
        'line3' => 'Si vous n\'avez pas demandé la suppression de votre compte, veuillez contacter le support immédiatement.',
      ),
    );
