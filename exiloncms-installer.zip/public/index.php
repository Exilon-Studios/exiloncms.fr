<?php
// Set this flag so the installer knows rewrite is working
$validInstallationUrlRewrite = true;

// Include the main installer
require __DIR__.'/../index.php';
