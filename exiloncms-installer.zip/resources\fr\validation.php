<?php

return array (
      'hex_color' => 'Le champ :attribute doit être une couleur hexadécimale valide.',
      'slug' => 'Le champ :attribute doit être un slug valide.',
      'username' => 'Le champ :attribute doit être un nom d\'utilisateur valide.',
    );
