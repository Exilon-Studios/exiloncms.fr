<?php
// Redirect to installer
header("Location: /installer/");
exit;
