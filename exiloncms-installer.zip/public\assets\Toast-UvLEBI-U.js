import{r as a,j as s}from"./app-CPNocFrY.js";let m=0;const j=()=>{const[t,n]=a.useState([]),e=a.useCallback((r,o,d)=>{const x=`toast-${++m}`,g={id:x,type:r,message:o,duration:d};return console[r==="error"?"error":r==="warning"?"warn":"log"](`[Toast ${r.toUpperCase()}]`,o),n(f=>[...f,g]),x},[]),c=a.useCallback(r=>{n(o=>o.filter(d=>d.id!==r))},[]),i=a.useCallback((r,o)=>e("success",r,o),[e]),l=a.useCallback((r,o)=>e("error",r,o),[e]),u=a.useCallback((r,o)=>e("warning",r,o),[e]),p=a.useCallback((r,o)=>e("info",r,o),[e]),b=a.useCallback(()=>{n([])},[]);return{toasts:t,show:e,success:i,error:l,warning:u,info:p,remove:c,clear:b}},y=({toast:t,onRemove:n})=>{a.useEffect(()=>{const i=t.duration??(t.type==="error"?5e3:3e3),l=setTimeout(()=>n(t.id),i);return()=>clearTimeout(l)},[t,n]);const c={success:{bg:"rgba(34, 197, 94, 0.15)",border:"rgba(34, 197, 94, 0.3)",text:"#22c55e"},error:{bg:"rgba(239, 68, 68, 0.15)",border:"rgba(239, 68, 68, 0.3)",text:"#ef4444"},warning:{bg:"rgba(251, 191, 36, 0.15)",border:"rgba(251, 191, 36, 0.3)",text:"#fbbf24"},info:{bg:"rgba(59, 130, 246, 0.15)",border:"rgba(59, 130, 246, 0.3)",text:"#3b82f6"}}[t.type];return s.jsxs("div",{style:{padding:"12px 16px",background:c.bg,border:`1px solid ${c.border}`,borderRadius:"8px",color:c.text,fontSize:"13px",display:"flex",alignItems:"center",gap:"10px",minWidth:"300px",maxWidth:"400px",animation:"slideIn 0.3s ease-out"},children:[s.jsx("span",{style:{flex:1},children:t.message}),s.jsx("button",{onClick:()=>n(t.id),style:{background:"none",border:"none",color:c.text,cursor:"pointer",padding:"2px",opacity:.7},onMouseOver:i=>{i.currentTarget.style.opacity="1"},onMouseOut:i=>{i.currentTarget.style.opacity="0.7"},children:s.jsxs("svg",{width:"16",height:"16",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[s.jsx("line",{x1:"18",y1:"6",x2:"6",y2:"18"}),s.jsx("line",{x1:"6",y1:"6",x2:"18",y2:"18"})]})})]})},C=({toasts:t,onRemove:n})=>t.length===0?null:s.jsxs(s.Fragment,{children:[s.jsx("style",{children:`
        @keyframes slideIn {
          from {
            opacity: 0;
            transform: translateY(-20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        @keyframes slideOut {
          from {
            opacity: 1;
            transform: translateY(0);
          }
          to {
            opacity: 0;
            transform: translateY(-20px);
          }
        }
      `}),s.jsx("div",{style:{position:"fixed",top:"20px",right:"20px",zIndex:9999,display:"flex",flexDirection:"column",gap:"10px"},children:t.map(e=>s.jsx(y,{toast:e,onRemove:n},e.id))})]});export{C as T,j as u};
