# ExilonCMS Installer

Welcome to ExilonCMS! This installer will download and set up the latest version of ExilonCMS on your server.

## Requirements

- PHP 8.2 or higher
- Required PHP extensions: bcmath, ctype, json, mbstring, openssl, PDO, tokenizer, xml, xmlwriter, curl, fileinfo, zip
- Write permissions in the installation directory

## Installation

1. Upload all files to your web server root
2. Point your browser to your site URL
3. Follow the installation wizard
4. After installation, delete the installer files

## Support

For help and documentation, visit https://exiloncms.fr