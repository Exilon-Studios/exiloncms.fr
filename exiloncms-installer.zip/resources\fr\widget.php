<?php

// Alias vers les traductions de widget du plugin shop
// Ce fichier permet à l'éditeur de traduction en ligne de trouver les clés

return array (
      'title' => 'Boutique',
      'recent_orders' => 'Commandes récentes',
    );
