<?php

namespace MCCMS\Console\Commands;

use MCCMS\Extensions\Plugin\PluginManager;
use Illuminate\Console\Command;
use Illuminate\Filesystem\Filesystem;

class PluginClearCommand extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'plugin:clear';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Cache the plugins service providers';

    /**
     * Execute the console command.
     */
    public function handle(Filesystem $files, PluginManager $plugins)
    {
        if ($files->exists($plugins->getCachedPluginsPath())) {
            $files->delete($plugins->getCachedPluginsPath());
        }

        $this->info('Cached plugins files removed.');
    }
}
