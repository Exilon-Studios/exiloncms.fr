<?php

namespace MCCMS\Games\Steam\Servers;

use MCCMS\Games\Steam\SteamID;
use MCCMS\Models\User;

trait SteamBridge
{
    public function replaceSteamPlaceholders(string $command, ?User $user = null): string
    {
        if ($user === null) {
            return $this->replacePlaceholders($command, $user);
        }

        return $this->replacePlaceholders($command, $user)
            ->replace('{game_id}', $user->game_id)
            ->replace('{steam_id}', $user->game_id)
            ->replace('{steam_hex}', dechex((int) $user->game_id))
            ->replace('{steam_id_32}', SteamID::convertTo32((int) $user->game_id));
    }
}
