<?php

namespace MCCMS\Games;

enum UserAttribute: string
{
    case ID = 'game_id';

    case NAME = 'name';
}
