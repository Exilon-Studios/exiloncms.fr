<?php

return [
    /*
    |--------------------------------------------------------------------------
    | Traductions des pages
    |--------------------------------------------------------------------------
    |
    | Traductions pour les pages principales du site
    |
    */

    'title' => 'Accueil',

    'site' => [
        'default_name' => 'MC-CMS',
        'default_description' => 'Système de gestion de contenu moderne pour les serveurs de jeu',
    ],
];
